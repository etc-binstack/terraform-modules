from .email import Email


class To(Email):
    """A to email address with an optional name."""
